/* tslint:disable */
/* eslint-disable */

export class WasmExplorer {
    free(): void;
    [Symbol.dispose](): void;
    detail_caption(deployment: string): string;
    metadata_json(): string;
    constructor(csv_content: string);
    render_detail(deployment: string): string;
    render_hour_heatmap(): string;
    render_overview(bucket: string): string;
}

export function init_runtime(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_wasmexplorer_free: (a: number, b: number) => void;
    readonly init_runtime: () => void;
    readonly wasmexplorer_detail_caption: (a: number, b: number, c: number) => [number, number, number, number];
    readonly wasmexplorer_metadata_json: (a: number) => [number, number, number, number];
    readonly wasmexplorer_new: (a: number, b: number) => [number, number, number];
    readonly wasmexplorer_render_detail: (a: number, b: number, c: number) => [number, number, number, number];
    readonly wasmexplorer_render_hour_heatmap: (a: number) => [number, number, number, number];
    readonly wasmexplorer_render_overview: (a: number, b: number, c: number) => [number, number, number, number];
    readonly rust_lz4_wasm_shim_calloc: (a: number, b: number) => number;
    readonly rust_lz4_wasm_shim_free: (a: number) => void;
    readonly rust_lz4_wasm_shim_malloc: (a: number) => number;
    readonly rust_lz4_wasm_shim_memcmp: (a: number, b: number, c: number) => number;
    readonly rust_lz4_wasm_shim_memcpy: (a: number, b: number, c: number) => number;
    readonly rust_lz4_wasm_shim_memmove: (a: number, b: number, c: number) => number;
    readonly rust_lz4_wasm_shim_memset: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_qsort: (a: number, b: number, c: number, d: number) => void;
    readonly rust_zstd_wasm_shim_calloc: (a: number, b: number) => number;
    readonly rust_zstd_wasm_shim_free: (a: number) => void;
    readonly rust_zstd_wasm_shim_memcmp: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_malloc: (a: number) => number;
    readonly rust_zstd_wasm_shim_memcpy: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_memmove: (a: number, b: number, c: number) => number;
    readonly rust_zstd_wasm_shim_memset: (a: number, b: number, c: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
